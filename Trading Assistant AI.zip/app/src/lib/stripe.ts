import { loadStripe, type Stripe } from '@stripe/stripe-js';
import type { SubscriptionPlan } from '@/types';

// Initialize Stripe
let stripePromise: Promise<Stripe | null>;

export const getStripe = (): Promise<Stripe | null> => {
  if (!stripePromise) {
    stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY || '');
  }
  return stripePromise;
};

// Subscription Plans
export const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: 'free',
    name: 'Free Plan',
    price: 0,
    interval: 'month',
    features: [
      'Basic market data (BTC, ETH)',
      'RSI indicator',
      'Limited AI insights (3/day)',
      'Basic charts',
      'Email support'
    ],
    stripePriceId: ''
  },
  {
    id: 'premium',
    name: 'Premium Plan',
    price: 29.99,
    interval: 'month',
    features: [
      'All market data access',
      'All technical indicators (RSI, MA50, MA200)',
      'Unlimited AI insights',
      'Advanced charts with patterns',
      'Price alerts',
      'Analysis history',
      'Priority support',
      'Telegram notifications'
    ],
    stripePriceId: import.meta.env.VITE_STRIPE_PREMIUM_PRICE_ID || ''
  }
];

// Create checkout session
export const createCheckoutSession = async (priceId: string, userId: string): Promise<{ sessionId: string }> => {
  const response = await fetch('/api/create-checkout-session', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ priceId, userId })
  });
  
  if (!response.ok) {
    throw new Error('Failed to create checkout session');
  }
  
  return response.json();
};

// Create portal session
export const createPortalSession = async (userId: string): Promise<{ url: string }> => {
  const response = await fetch('/api/create-portal-session', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId })
  });
  
  if (!response.ok) {
    throw new Error('Failed to create portal session');
  }
  
  return response.json();
};
