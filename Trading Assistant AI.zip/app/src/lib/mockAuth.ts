// Mock Authentication System for Demo Purposes
// This replaces Firebase auth with local storage-based auth for demonstration

import type { User } from '@/types';

const MOCK_USERS_KEY = 'trading_ai_mock_users';
const CURRENT_USER_KEY = 'trading_ai_current_user';

interface MockUser {
  id: string;
  email: string;
  password: string;
  displayName: string;
  photoURL: string | null;
  subscription: 'free' | 'premium';
  createdAt: Date;
  lastLoginAt: Date;
}

// Get stored mock users
const getStoredUsers = (): MockUser[] => {
  try {
    const stored = localStorage.getItem(MOCK_USERS_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
};

// Store mock users
const storeUsers = (users: MockUser[]) => {
  localStorage.setItem(MOCK_USERS_KEY, JSON.stringify(users));
};

// Generate unique ID
const generateId = (): string => {
  return 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
};

// Mock Firebase User type
export interface FirebaseUser {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
}

// Sign up with email and password
export const signUpWithEmail = async (
  email: string,
  password: string,
  displayName: string
): Promise<User> => {
  const users = getStoredUsers();

  // Check if user already exists
  if (users.find((u) => u.email === email)) {
    throw new Error('Email already in use');
  }

  const newUser: MockUser = {
    id: generateId(),
    email,
    password,
    displayName,
    photoURL: null,
    subscription: 'free',
    createdAt: new Date(),
    lastLoginAt: new Date(),
  };

  users.push(newUser);
  storeUsers(users);

  // Store current user
  localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(newUser));

  return {
    id: newUser.id,
    email: newUser.email,
    displayName: newUser.displayName,
    photoURL: newUser.photoURL,
    subscription: newUser.subscription,
    createdAt: newUser.createdAt,
    lastLoginAt: newUser.lastLoginAt,
  };
};

// Sign in with email and password
export const signInWithEmail = async (
  email: string,
  password: string
): Promise<User> => {
  const users = getStoredUsers();
  const user = users.find((u) => u.email === email && u.password === password);

  if (!user) {
    throw new Error('Invalid email or password');
  }

  user.lastLoginAt = new Date();
  storeUsers(users);
  localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));

  return {
    id: user.id,
    email: user.email,
    displayName: user.displayName,
    photoURL: user.photoURL,
    subscription: user.subscription,
    createdAt: new Date(user.createdAt),
    lastLoginAt: new Date(user.lastLoginAt),
  };
};

// Sign in with Google (mock)
export const signInWithGoogle = async (): Promise<User> => {
  // Simulate Google sign-in with a mock user
  const mockGoogleUser: MockUser = {
    id: generateId(),
    email: 'google.user@gmail.com',
    password: 'google_oauth',
    displayName: 'Google User',
    photoURL: 'https://ui-avatars.com/api/?name=Google+User&background=random',
    subscription: 'free',
    createdAt: new Date(),
    lastLoginAt: new Date(),
  };

  const users = getStoredUsers();

  // Check if this Google user already exists
  const existingUser = users.find((u) => u.email === mockGoogleUser.email);

  if (existingUser) {
    existingUser.lastLoginAt = new Date();
    storeUsers(users);
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(existingUser));

    return {
      id: existingUser.id,
      email: existingUser.email,
      displayName: existingUser.displayName,
      photoURL: existingUser.photoURL,
      subscription: existingUser.subscription,
      createdAt: new Date(existingUser.createdAt),
      lastLoginAt: new Date(existingUser.lastLoginAt),
    };
  }

  // Create new Google user
  users.push(mockGoogleUser);
  storeUsers(users);
  localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(mockGoogleUser));

  return {
    id: mockGoogleUser.id,
    email: mockGoogleUser.email,
    displayName: mockGoogleUser.displayName,
    photoURL: mockGoogleUser.photoURL,
    subscription: mockGoogleUser.subscription,
    createdAt: mockGoogleUser.createdAt,
    lastLoginAt: mockGoogleUser.lastLoginAt,
  };
};

// Sign out
export const logOut = async (): Promise<void> => {
  localStorage.removeItem(CURRENT_USER_KEY);
};

// Get current user
export const getCurrentUser = (): User | null => {
  try {
    const stored = localStorage.getItem(CURRENT_USER_KEY);
    if (!stored) return null;

    const user = JSON.parse(stored);
    return {
      id: user.id,
      email: user.email,
      displayName: user.displayName,
      photoURL: user.photoURL,
      subscription: user.subscription,
      createdAt: new Date(user.createdAt),
      lastLoginAt: new Date(user.lastLoginAt),
    };
  } catch {
    return null;
  }
};

// Get user document (mock Firestore)
export const getUserDocument = async (uid: string): Promise<User | null> => {
  const users = getStoredUsers();
  const user = users.find((u) => u.id === uid);

  if (!user) return null;

  return {
    id: user.id,
    email: user.email,
    displayName: user.displayName,
    photoURL: user.photoURL,
    subscription: user.subscription,
    createdAt: new Date(user.createdAt),
    lastLoginAt: new Date(user.lastLoginAt),
  };
};

// Update user subscription
export const updateUserSubscription = async (
  userId: string,
  subscription: 'free' | 'premium'
): Promise<void> => {
  const users = getStoredUsers();
  const user = users.find((u) => u.id === userId);

  if (user) {
    user.subscription = subscription;
    storeUsers(users);

    // Update current user if it's the same user
    const currentUser = getCurrentUser();
    if (currentUser && currentUser.id === userId) {
      currentUser.subscription = subscription;
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify({ ...user, subscription, password: user.password }));
    }
  }
};

// Create user document
export const createUserDocument = async (
  firebaseUser: FirebaseUser,
  displayName?: string
): Promise<User> => {
  const newUser: MockUser = {
    id: firebaseUser.uid,
    email: firebaseUser.email || '',
    password: 'oauth_password',
    displayName: displayName || firebaseUser.displayName || 'User',
    photoURL: firebaseUser.photoURL,
    subscription: 'free',
    createdAt: new Date(),
    lastLoginAt: new Date(),
  };

  const users = getStoredUsers();
  users.push(newUser);
  storeUsers(users);

  return {
    id: newUser.id,
    email: newUser.email,
    displayName: newUser.displayName,
    photoURL: newUser.photoURL,
    subscription: newUser.subscription,
    createdAt: newUser.createdAt,
    lastLoginAt: newUser.lastLoginAt,
  };
};

// On auth state changed callback type
type AuthStateCallback = (user: FirebaseUser | null) => void;

// Subscribe to auth state changes
export const onAuthStateChanged = (
  _auth: any,
  callback: AuthStateCallback
): (() => void) => {
  // Check current user immediately
  const currentUser = getCurrentUser();

  if (currentUser) {
    callback({
      uid: currentUser.id,
      email: currentUser.email,
      displayName: currentUser.displayName,
      photoURL: currentUser.photoURL,
    });
  } else {
    callback(null);
  }

  // Set up storage event listener for cross-tab sync
  const handleStorageChange = (e: StorageEvent) => {
    if (e.key === CURRENT_USER_KEY) {
      const user = getCurrentUser();
      if (user) {
        callback({
          uid: user.id,
          email: user.email,
          displayName: user.displayName,
          photoURL: user.photoURL,
        });
      } else {
        callback(null);
      }
    }
  };

  window.addEventListener('storage', handleStorageChange);

  // Return unsubscribe function
  return () => {
    window.removeEventListener('storage', handleStorageChange);
  };
};

// Mock auth object - used for compatibility with Firebase API
export const auth = {
  currentUser: null as FirebaseUser | null,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  _isMock: true,
};

// Export types
export type { MockUser };
