import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  GoogleAuthProvider,
  signInWithPopup,
  updateProfile,
  type User as FirebaseUser
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc,
  collection,
  query,
  where,
  orderBy,
  getDocs,
  addDoc,
  serverTimestamp,
  type Timestamp
} from 'firebase/firestore';
import type { User, SubscriptionType, AnalysisHistory, PriceAlert } from '@/types';

// Firebase configuration - Replace with your actual config
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || 'your-api-key',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || 'your-auth-domain',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'your-project-id',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || 'your-storage-bucket',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || 'your-sender-id',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || 'your-app-id'
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

// Google Auth Provider
const googleProvider = new GoogleAuthProvider();

// Auth Functions
export const signUpWithEmail = async (
  email: string, 
  password: string, 
  displayName: string
): Promise<User> => {
  const userCredential = await createUserWithEmailAndPassword(auth, email, password);
  await updateProfile(userCredential.user, { displayName });
  
  const user = await createUserDocument(userCredential.user, displayName);
  return user;
};

export const signInWithEmail = async (email: string, password: string): Promise<User> => {
  const userCredential = await signInWithEmailAndPassword(auth, email, password);
  const user = await getUserDocument(userCredential.user.uid);
  if (user) {
    await updateDoc(doc(db, 'users', userCredential.user.uid), {
      lastLoginAt: serverTimestamp()
    });
  }
  return user || createUserDocument(userCredential.user);
};

export const signInWithGoogle = async (): Promise<User> => {
  const userCredential = await signInWithPopup(auth, googleProvider);
  const user = await getUserDocument(userCredential.user.uid);
  if (!user) {
    return createUserDocument(userCredential.user);
  }
  await updateDoc(doc(db, 'users', userCredential.user.uid), {
    lastLoginAt: serverTimestamp()
  });
  return user;
};

export const logOut = async (): Promise<void> => {
  await signOut(auth);
};

// Firestore Functions
export const createUserDocument = async (
  firebaseUser: FirebaseUser, 
  displayName?: string
): Promise<User> => {
  const userRef = doc(db, 'users', firebaseUser.uid);
  const userData: Omit<User, 'id'> = {
    email: firebaseUser.email || '',
    displayName: displayName || firebaseUser.displayName || null,
    photoURL: firebaseUser.photoURL,
    subscription: 'free',
    createdAt: new Date(),
    lastLoginAt: new Date()
  };
  
  await setDoc(userRef, {
    ...userData,
    createdAt: serverTimestamp(),
    lastLoginAt: serverTimestamp()
  });
  
  return { id: firebaseUser.uid, ...userData };
};

export const getUserDocument = async (uid: string): Promise<User | null> => {
  const userRef = doc(db, 'users', uid);
  const userSnap = await getDoc(userRef);
  
  if (userSnap.exists()) {
    const data = userSnap.data();
    return {
      id: userSnap.id,
      email: data.email,
      displayName: data.displayName,
      photoURL: data.photoURL,
      subscription: data.subscription,
      createdAt: data.createdAt?.toDate(),
      lastLoginAt: data.lastLoginAt?.toDate()
    } as User;
  }
  return null;
};

export const updateUserSubscription = async (
  userId: string, 
  subscription: SubscriptionType
): Promise<void> => {
  const userRef = doc(db, 'users', userId);
  await updateDoc(userRef, { subscription });
};

// History Functions
export const saveAnalysisHistory = async (
  userId: string,
  symbol: string,
  insight: any
): Promise<void> => {
  const historyRef = collection(db, 'analysisHistory');
  await addDoc(historyRef, {
    userId,
    symbol,
    insight,
    createdAt: serverTimestamp()
  });
};

export const getUserAnalysisHistory = async (userId: string): Promise<AnalysisHistory[]> => {
  const historyRef = collection(db, 'analysisHistory');
  const q = query(
    historyRef,
    where('userId', '==', userId),
    orderBy('createdAt', 'desc')
  );
  
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt?.toDate()
  })) as AnalysisHistory[];
};

// Alert Functions
export const createPriceAlert = async (
  userId: string,
  alert: Omit<PriceAlert, 'id' | 'userId' | 'createdAt' | 'triggeredAt'>
): Promise<string> => {
  const alertsRef = collection(db, 'priceAlerts');
  const docRef = await addDoc(alertsRef, {
    userId,
    ...alert,
    createdAt: serverTimestamp()
  });
  return docRef.id;
};

export const getUserAlerts = async (userId: string): Promise<PriceAlert[]> => {
  const alertsRef = collection(db, 'priceAlerts');
  const q = query(
    alertsRef,
    where('userId', '==', userId),
    orderBy('createdAt', 'desc')
  );
  
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt?.toDate(),
    triggeredAt: doc.data().triggeredAt?.toDate()
  })) as PriceAlert[];
};

export const deleteAlert = async (alertId: string): Promise<void> => {
  await updateDoc(doc(db, 'priceAlerts', alertId), { isActive: false });
};

export { onAuthStateChanged, serverTimestamp };
export type { FirebaseUser, Timestamp };
