import React from 'react';
import {
  ComposedChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell
} from 'recharts';
import type { CandlestickData } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';

interface TradingChartProps {
  data: CandlestickData[];
  symbol: string;
  height?: number;
}

// Transform candlestick data for recharts
const transformCandleData = (data: CandlestickData[]) => {
  return data.map(candle => {
    const isBullish = candle.close >= candle.open;
    const bodyHeight = Math.abs(candle.close - candle.open);
    const wickHigh = candle.high - Math.max(candle.open, candle.close);
    const wickLow = Math.min(candle.open, candle.close) - candle.low;
    
    return {
      time: new Date(candle.time).toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit'
      }),
      timestamp: candle.time,
      open: candle.open,
      high: candle.high,
      low: candle.low,
      close: candle.close,
      volume: candle.volume,
      isBullish,
      bodyTop: Math.max(candle.open, candle.close),
      bodyBottom: Math.min(candle.open, candle.close),
      bodyHeight,
      wickHigh,
      wickLow,
    };
  });
};

// Custom candlestick shape
const CandlestickShape = (props: any) => {
  const { x, y, width, height, payload } = props;
  
  if (!payload) return null;
  
  const color = payload.isBullish ? '#10b981' : '#f43f5e';
  const centerX = x + width / 2;
  const candleWidth = Math.max(width * 0.6, 2);
  
  // Calculate positions
  const priceRange = payload.high - payload.low;
  
  if (priceRange === 0) return null;
  
  const scale = height / priceRange;
  
  const wickTopY = y - payload.wickHigh * scale;
  const wickBottomY = y + height + payload.wickLow * scale;
  const bodyTopY = y;
  const bodyBottomY = y + height;
  
  return (
    <g>
      {/* Upper wick */}
      <line
        x1={centerX}
        y1={wickTopY}
        x2={centerX}
        y2={bodyTopY}
        stroke={color}
        strokeWidth={1}
      />
      {/* Lower wick */}
      <line
        x1={centerX}
        y1={bodyBottomY}
        x2={centerX}
        y2={wickBottomY}
        stroke={color}
        strokeWidth={1}
      />
      {/* Body */}
      <rect
        x={centerX - candleWidth / 2}
        y={bodyTopY}
        width={candleWidth}
        height={Math.max(bodyBottomY - bodyTopY, 1)}
        fill={payload.isBullish ? color : color}
        stroke={color}
        strokeWidth={1}
      />
    </g>
  );
};

// Custom tooltip
const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-slate-900 border border-slate-700 rounded-lg p-3 shadow-lg">
        <p className="text-slate-400 text-xs mb-2">{data.time}</p>
        <div className="space-y-1 text-sm">
          <div className="flex justify-between gap-4">
            <span className="text-slate-500">Open:</span>
            <span className="text-white">${data.open.toFixed(2)}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-slate-500">High:</span>
            <span className="text-emerald-400">${data.high.toFixed(2)}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-slate-500">Low:</span>
            <span className="text-rose-400">${data.low.toFixed(2)}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-slate-500">Close:</span>
            <span className={data.isBullish ? 'text-emerald-400' : 'text-rose-400'}>
              ${data.close.toFixed(2)}
            </span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-slate-500">Volume:</span>
            <span className="text-white">{data.volume.toFixed(4)}</span>
          </div>
        </div>
      </div>
    );
  }
  return null;
};

export const TradingChart: React.FC<TradingChartProps> = ({ 
  data, 
  symbol, 
  height = 400 
}) => {
  const transformedData = React.useMemo(() => transformCandleData(data), [data]);
  
  // Calculate price statistics
  const prices = data.map(d => [d.open, d.high, d.low, d.close]).flat();
  const minPrice = Math.min(...prices);
  const maxPrice = Math.max(...prices);
  const priceRange = maxPrice - minPrice;
  const padding = priceRange * 0.1;

  if (data.length === 0) {
    return (
      <Card className="border-slate-800 bg-slate-950/50">
        <CardHeader>
          <CardTitle className="text-white">{symbol} Chart</CardTitle>
        </CardHeader>
        <CardContent>
          <Skeleton className="w-full h-[400px] bg-slate-800" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-slate-800 bg-slate-950/50">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-white">{symbol} Chart</CardTitle>
        <div className="flex items-center gap-2 text-sm text-slate-400">
          <span className="flex items-center gap-1">
            <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
            Bullish
          </span>
          <span className="flex items-center gap-1">
            <span className="w-3 h-3 rounded-full bg-rose-500"></span>
            Bearish
          </span>
        </div>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={height}>
          <ComposedChart
            data={transformedData}
            margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
            <XAxis 
              dataKey="time" 
              stroke="#475569"
              tick={{ fill: '#94a3b8', fontSize: 10 }}
              tickLine={{ stroke: '#475569' }}
              minTickGap={30}
            />
            <YAxis 
              domain={[minPrice - padding, maxPrice + padding]}
              stroke="#475569"
              tick={{ fill: '#94a3b8', fontSize: 10 }}
              tickLine={{ stroke: '#475569' }}
              tickFormatter={(value) => `$${value.toFixed(0)}`}
              width={60}
            />
            <Tooltip content={<CustomTooltip />} />
            <Bar
              dataKey="bodyHeight"
              shape={<CandlestickShape />}
              isAnimationActive={false}
            >
              {transformedData.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={entry.isBullish ? '#10b981' : '#f43f5e'}
                />
              ))}
            </Bar>
          </ComposedChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};
