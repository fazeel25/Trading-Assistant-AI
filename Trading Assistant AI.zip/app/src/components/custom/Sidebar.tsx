import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  LayoutDashboard, 
  LineChart, 
  History, 
  Bell, 
  CreditCard, 
  Settings, 
  HelpCircle,
  Crown,
  TrendingUp,
  X
} from 'lucide-react';

interface SidebarProps {
  className?: string;
  isOpen?: boolean;
  onClose?: () => void;
  activeTab: string;
  onTabChange: (tab: string) => void;
}

interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  premium?: boolean;
}

const navItems: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'markets', label: 'Markets', icon: TrendingUp },
  { id: 'signals', label: 'AI Signals', icon: LineChart },
  { id: 'history', label: 'History', icon: History, premium: true },
  { id: 'alerts', label: 'Price Alerts', icon: Bell, premium: true },
  { id: 'billing', label: 'Billing', icon: CreditCard },
  { id: 'settings', label: 'Settings', icon: Settings },
  { id: 'help', label: 'Help & Support', icon: HelpCircle },
];

export const Sidebar: React.FC<SidebarProps> = ({ 
  className, 
  isOpen = true, 
  onClose,
  activeTab,
  onTabChange
}) => {
  const { user } = useAuth();
  const isPremium = user?.subscription === 'premium';

  const handleTabClick = (tabId: string) => {
    onTabChange(tabId);
    if (onClose) onClose();
  };

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && onClose && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside 
        className={cn(
          "fixed md:sticky top-0 left-0 z-50 h-screen w-64 border-r border-slate-800 bg-slate-950 transition-transform duration-300 ease-in-out",
          !isOpen && "-translate-x-full md:translate-x-0 md:hidden",
          className
        )}
      >
        <div className="flex h-full flex-col">
          {/* Header */}
          <div className="flex h-16 items-center justify-between px-4 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center">
                <LineChart className="h-5 w-5 text-white" />
              </div>
              <span className="text-lg font-bold text-white">Trading AI</span>
            </div>
            {onClose && (
              <Button variant="ghost" size="icon" onClick={onClose} className="md:hidden hover:bg-slate-800">
                <X className="h-5 w-5 text-slate-400" />
              </Button>
            )}
          </div>

          {/* Navigation */}
          <ScrollArea className="flex-1 py-4">
            <nav className="space-y-1 px-3">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                const isLocked = item.premium && !isPremium;

                return (
                  <button
                    key={item.id}
                    onClick={() => !isLocked && handleTabClick(item.id)}
                    disabled={isLocked}
                    className={cn(
                      "w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                      isActive 
                        ? "bg-indigo-600/20 text-indigo-400 border border-indigo-600/30" 
                        : "text-slate-400 hover:bg-slate-900 hover:text-slate-200",
                      isLocked && "opacity-50 cursor-not-allowed hover:bg-transparent hover:text-slate-400"
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="h-4 w-4" />
                      {item.label}
                    </div>
                    {item.premium && !isPremium && (
                      <Badge variant="outline" className="bg-amber-500/10 text-amber-400 border-amber-500/30 text-xs">
                        <Crown className="h-3 w-3 mr-1" />
                        PRO
                      </Badge>
                    )}
                  </button>
                );
              })}
            </nav>
          </ScrollArea>

          {/* Footer */}
          <div className="p-4 border-t border-slate-800">
            {!isPremium && (
              <div className="p-4 rounded-lg bg-gradient-to-br from-indigo-600/20 to-purple-600/20 border border-indigo-500/30">
                <div className="flex items-center gap-2 mb-2">
                  <Crown className="h-5 w-5 text-amber-400" />
                  <span className="font-semibold text-white">Upgrade to Pro</span>
                </div>
                <p className="text-xs text-slate-400 mb-3">
                  Get unlimited AI insights, alerts, and more.
                </p>
                <Button 
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-sm"
                  onClick={() => handleTabClick('billing')}
                >
                  Upgrade Now
                </Button>
              </div>
            )}
          </div>
        </div>
      </aside>
    </>
  );
};
