import React, { useState } from 'react';
import { LoginForm } from '@/components/auth/LoginForm';
import { SignupForm } from '@/components/auth/SignupForm';
import { LineChart, TrendingUp, Shield, Zap } from 'lucide-react';

export const AuthPage: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);

  const toggleForm = () => {
    setIsLogin(!isLogin);
  };

  const features = [
    {
      icon: TrendingUp,
      title: 'AI-Powered Analysis',
      description: 'Get intelligent trading signals based on technical indicators'
    },
    {
      icon: Shield,
      title: 'Risk Management',
      description: 'Probability-based insights with clear risk disclaimers'
    },
    {
      icon: Zap,
      title: 'Real-time Data',
      description: 'Live market data from Binance with advanced charts'
    }
  ];

  return (
    <div className="min-h-screen bg-slate-950 flex">
      {/* Left Section - Features */}
      <div className="hidden lg:flex lg:w-1/2 xl:w-3/5 relative overflow-hidden">
        {/* Background Gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-900/50 via-slate-950 to-purple-900/30" />
        
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        </div>

        {/* Content */}
        <div className="relative z-10 flex flex-col justify-center px-12 xl:px-20">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-12 h-12 rounded-xl bg-indigo-600 flex items-center justify-center">
              <LineChart className="h-7 w-7 text-white" />
            </div>
            <span className="text-2xl font-bold text-white">Trading Assistant AI</span>
          </div>

          <h1 className="text-4xl xl:text-5xl font-bold text-white mb-6 leading-tight">
            Make Smarter<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">
              Trading Decisions
            </span>
          </h1>

          <p className="text-lg text-slate-400 mb-12 max-w-lg">
            Get AI-powered trading insights based on technical analysis. 
            Not financial advice — just intelligent probability-based signals.
          </p>

          <div className="space-y-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-indigo-600/20 flex items-center justify-center flex-shrink-0">
                    <Icon className="h-5 w-5 text-indigo-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white mb-1">{feature.title}</h3>
                    <p className="text-sm text-slate-400">{feature.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Right Section - Auth Form */}
      <div className="w-full lg:w-1/2 xl:w-2/5 flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          {/* Mobile Logo */}
          <div className="lg:hidden flex items-center justify-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-lg bg-indigo-600 flex items-center justify-center">
              <LineChart className="h-6 w-6 text-white" />
            </div>
            <span className="text-xl font-bold text-white">Trading AI</span>
          </div>

          {isLogin ? (
            <LoginForm onToggleForm={toggleForm} />
          ) : (
            <SignupForm onToggleForm={toggleForm} />
          )}

          {/* Trust Badges */}
          <div className="mt-8 flex items-center justify-center gap-6 text-slate-500">
            <div className="flex items-center gap-2 text-xs">
              <Shield className="h-4 w-4" />
              <span>Secure</span>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <Zap className="h-4 w-4" />
              <span>Real-time</span>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <TrendingUp className="h-4 w-4" />
              <span>AI-Powered</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
