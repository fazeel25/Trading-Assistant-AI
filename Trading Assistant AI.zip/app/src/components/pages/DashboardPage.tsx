import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Header } from '@/components/custom/Header';
import { Sidebar } from '@/components/custom/Sidebar';
import { TradingChart } from '@/components/charts/TradingChart';
import { SignalCard } from '@/components/dashboard/SignalCard';
import { MarketOverview } from '@/components/dashboard/MarketOverview';
import { IndicatorPanel } from '@/components/dashboard/IndicatorPanel';
import { SubscriptionPlans } from '@/components/dashboard/SubscriptionPlans';
import { useTradingData, useMultipleMarketData } from '@/hooks/useTradingData';
import { POPULAR_PAIRS } from '@/services/binanceApi';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { RefreshCw, TrendingUp } from 'lucide-react';

export const DashboardPage: React.FC = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedSymbol, setSelectedSymbol] = useState('BTCUSDT');
  const [selectedInterval, setSelectedInterval] = useState('1h');

  const { 
    candlesticks, 
    insight, 
    loading: dataLoading, 
    refreshData 
  } = useTradingData(selectedSymbol, selectedInterval);

  const { 
    marketData: overviewData, 
    loading: overviewLoading, 
    refreshData: refreshOverview 
  } = useMultipleMarketData(POPULAR_PAIRS.slice(0, 5));

  const intervals = [
    { value: '15m', label: '15 Minutes' },
    { value: '1h', label: '1 Hour' },
    { value: '4h', label: '4 Hours' },
    { value: '1d', label: '1 Day' },
  ];

  const renderDashboard = () => (
    <div className="space-y-6">
      {/* Symbol Selector */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <Select value={selectedSymbol} onValueChange={setSelectedSymbol}>
            <SelectTrigger className="w-[160px] bg-slate-900 border-slate-800 text-white">
              <SelectValue placeholder="Select Symbol" />
            </SelectTrigger>
            <SelectContent className="bg-slate-900 border-slate-800">
              {POPULAR_PAIRS.slice(0, 6).map((pair) => (
                <SelectItem 
                  key={pair} 
                  value={pair}
                  className="text-white hover:bg-slate-800 focus:bg-slate-800"
                >
                  {pair}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedInterval} onValueChange={setSelectedInterval}>
            <SelectTrigger className="w-[140px] bg-slate-900 border-slate-800 text-white">
              <SelectValue placeholder="Interval" />
            </SelectTrigger>
            <SelectContent className="bg-slate-900 border-slate-800">
              {intervals.map((interval) => (
                <SelectItem 
                  key={interval.value} 
                  value={interval.value}
                  className="text-white hover:bg-slate-800 focus:bg-slate-800"
                >
                  {interval.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Button 
          variant="outline" 
          onClick={refreshData}
          disabled={dataLoading}
          className="border-slate-700 bg-slate-900 text-white hover:bg-slate-800"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${dataLoading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Chart Section */}
        <div className="xl:col-span-2">
          {dataLoading ? (
            <Skeleton className="h-[500px] w-full bg-slate-800" />
          ) : (
            <TradingChart 
              data={candlesticks} 
              symbol={selectedSymbol}
              height={450}
            />
          )}
        </div>

        {/* Market Overview */}
        <div>
          <MarketOverview 
            marketData={overviewData}
            loading={overviewLoading}
            onRefresh={refreshOverview}
          />
        </div>
      </div>

      {/* Signals and Indicators */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {dataLoading ? (
          <>
            <Skeleton className="h-[400px] w-full bg-slate-800" />
            <Skeleton className="h-[400px] w-full bg-slate-800" />
          </>
        ) : (
          <>
            {insight && <SignalCard insight={insight} />}
            {insight && <IndicatorPanel indicators={insight.indicators} />}
          </>
        )}
      </div>
    </div>
  );

  const renderMarkets = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Markets</h2>
        <Button 
          variant="outline" 
          onClick={refreshOverview}
          disabled={overviewLoading}
          className="border-slate-700 bg-slate-900 text-white hover:bg-slate-800"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${overviewLoading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>
      <MarketOverview 
        marketData={overviewData}
        loading={overviewLoading}
        onRefresh={refreshOverview}
      />
    </div>
  );

  const renderSignals = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">AI Trading Signals</h2>
        <Button 
          variant="outline" 
          onClick={refreshData}
          disabled={dataLoading}
          className="border-slate-700 bg-slate-900 text-white hover:bg-slate-800"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${dataLoading ? 'animate-spin' : ''}`} />
          Generate New Signal
        </Button>
      </div>
      
      {dataLoading ? (
        <Skeleton className="h-[400px] w-full bg-slate-800" />
      ) : insight ? (
        <SignalCard insight={insight} />
      ) : (
        <div className="text-center py-12">
          <p className="text-slate-400">No signals available. Please refresh.</p>
        </div>
      )}
    </div>
  );

  const renderBilling = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">Subscription Plans</h2>
      <SubscriptionPlans currentPlan={user?.subscription} />
    </div>
  );

  const renderComingSoon = (title: string) => (
    <div className="flex flex-col items-center justify-center py-20">
      <div className="w-20 h-20 rounded-full bg-slate-800 flex items-center justify-center mb-4">
        <TrendingUp className="h-10 w-10 text-slate-500" />
      </div>
      <h2 className="text-2xl font-bold text-white mb-2">{title}</h2>
      <p className="text-slate-400">This feature is coming soon.</p>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return renderDashboard();
      case 'markets':
        return renderMarkets();
      case 'signals':
        return renderSignals();
      case 'history':
        return renderComingSoon('Analysis History');
      case 'alerts':
        return renderComingSoon('Price Alerts');
      case 'billing':
        return renderBilling();
      case 'settings':
        return renderComingSoon('Settings');
      case 'help':
        return renderComingSoon('Help & Support');
      default:
        return renderDashboard();
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <Header onMenuClick={() => setSidebarOpen(true)} />
      
      <div className="flex">
        <Sidebar 
          isOpen={sidebarOpen} 
          onClose={() => setSidebarOpen(false)}
          activeTab={activeTab}
          onTabChange={setActiveTab}
        />
        
        <main className="flex-1 p-4 md:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto">
            {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
};
