import React from 'react';
import type { TradingInsight } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  AlertTriangle,
  Activity,
  BarChart3,
  Target
} from 'lucide-react';
import { 
  getSignalColor, 
  getSignalBgColor, 
  getMarketConditionColor,
  getConfidenceColor,
  formatSignal,
  formatMarketCondition 
} from '@/services/aiInsights';

interface SignalCardProps {
  insight: TradingInsight;
}

export const SignalCard: React.FC<SignalCardProps> = ({ insight }) => {
  const { symbol, marketCondition, signal, confidence, reasoning, indicators, disclaimer } = insight;

  const getSignalIcon = () => {
    switch (signal) {
      case 'possible_buy':
        return <TrendingUp className="h-8 w-8" />;
      case 'possible_sell':
        return <TrendingDown className="h-8 w-8" />;
      case 'wait':
        return <Minus className="h-8 w-8" />;
    }
  };

  return (
    <Card className="border-slate-800 bg-slate-950/50">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl text-white flex items-center gap-2">
            <Activity className="h-5 w-5 text-indigo-500" />
            AI Trading Signal
          </CardTitle>
          <Badge 
            variant="outline" 
            className={getConfidenceColor(confidence)}
          >
            <Target className="h-3 w-3 mr-1" />
            {confidence.charAt(0).toUpperCase() + confidence.slice(1)} Confidence
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Main Signal Display */}
        <div className={`p-6 rounded-xl border-2 ${getSignalBgColor(signal)} flex items-center justify-between`}>
          <div>
            <p className="text-sm text-slate-400 mb-1">Signal for {symbol}</p>
            <h3 className={`text-3xl font-bold ${getSignalColor(signal)}`}>
              {formatSignal(signal)}
            </h3>
          </div>
          <div className={getSignalColor(signal)}>
            {getSignalIcon()}
          </div>
        </div>

        {/* Market Condition */}
        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 rounded-lg bg-slate-900/50 border border-slate-800">
            <p className="text-sm text-slate-400 mb-1">Market Condition</p>
            <p className={`text-lg font-semibold ${getMarketConditionColor(marketCondition)}`}>
              {formatMarketCondition(marketCondition)}
            </p>
          </div>
          <div className="p-4 rounded-lg bg-slate-900/50 border border-slate-800">
            <p className="text-sm text-slate-400 mb-1">Current Price</p>
            <p className="text-lg font-semibold text-white">
              ${indicators.currentPrice.toLocaleString()}
            </p>
          </div>
        </div>

        {/* Indicators */}
        <div className="p-4 rounded-lg bg-slate-900/50 border border-slate-800">
          <div className="flex items-center gap-2 mb-3">
            <BarChart3 className="h-4 w-4 text-indigo-500" />
            <p className="text-sm font-medium text-slate-300">Technical Indicators</p>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <p className="text-xs text-slate-500 mb-1">RSI (14)</p>
              <p className={`text-lg font-semibold ${
                indicators.rsi < 30 ? 'text-emerald-500' : 
                indicators.rsi > 70 ? 'text-rose-500' : 'text-amber-500'
              }`}>
                {indicators.rsi}
              </p>
            </div>
            <div className="text-center">
              <p className="text-xs text-slate-500 mb-1">MA50</p>
              <p className="text-lg font-semibold text-white">
                ${indicators.ma50.toLocaleString()}
              </p>
            </div>
            <div className="text-center">
              <p className="text-xs text-slate-500 mb-1">MA200</p>
              <p className="text-lg font-semibold text-white">
                ${indicators.ma200.toLocaleString()}
              </p>
            </div>
          </div>
        </div>

        {/* Reasoning */}
        <div className="p-4 rounded-lg bg-slate-900/50 border border-slate-800">
          <p className="text-sm font-medium text-slate-300 mb-2">AI Analysis</p>
          <p className="text-sm text-slate-400 leading-relaxed">{reasoning}</p>
        </div>

        {/* Disclaimer */}
        <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-950/30 border border-amber-800/50">
          <AlertTriangle className="h-4 w-4 text-amber-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-amber-400">{disclaimer}</p>
        </div>
      </CardContent>
    </Card>
  );
};
