import React from 'react';
import type { MarketData } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Activity, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

interface MarketOverviewProps {
  marketData: Record<string, MarketData>;
  loading: boolean;
  onRefresh: () => void;
}

export const MarketOverview: React.FC<MarketOverviewProps> = ({ 
  marketData, 
  loading,
  onRefresh 
}) => {
  const formatPrice = (price: number): string => {
    if (price >= 1000) {
      return price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
    return price.toLocaleString('en-US', { minimumFractionDigits: 4, maximumFractionDigits: 6 });
  };

  const formatChange = (change: number): string => {
    const prefix = change >= 0 ? '+' : '';
    return `${prefix}${change.toFixed(2)}%`;
  };

  if (loading) {
    return (
      <Card className="border-slate-800 bg-slate-950/50">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-white flex items-center gap-2">
            <Activity className="h-5 w-5 text-indigo-500" />
            Market Overview
          </CardTitle>
          <Skeleton className="h-8 w-8 bg-slate-800" />
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <Skeleton key={i} className="h-16 w-full bg-slate-800" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const dataEntries = Object.entries(marketData);

  if (dataEntries.length === 0) {
    return (
      <Card className="border-slate-800 bg-slate-950/50">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-white flex items-center gap-2">
            <Activity className="h-5 w-5 text-indigo-500" />
            Market Overview
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onRefresh}>
            <RefreshCw className="h-4 w-4 text-slate-400" />
          </Button>
        </CardHeader>
        <CardContent>
          <p className="text-slate-400 text-center py-8">No market data available</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-slate-800 bg-slate-950/50">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-white flex items-center gap-2">
          <Activity className="h-5 w-5 text-indigo-500" />
          Market Overview
        </CardTitle>
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={onRefresh}
          className="hover:bg-slate-800"
        >
          <RefreshCw className="h-4 w-4 text-slate-400" />
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {dataEntries.map(([symbol, data]) => (
            <div 
              key={symbol}
              className="flex items-center justify-between p-3 rounded-lg bg-slate-900/50 border border-slate-800 hover:border-slate-700 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  data.changePercent24h >= 0 ? 'bg-emerald-500/20' : 'bg-rose-500/20'
                }`}>
                  {data.changePercent24h >= 0 ? (
                    <TrendingUp className="h-4 w-4 text-emerald-500" />
                  ) : (
                    <TrendingDown className="h-4 w-4 text-rose-500" />
                  )}
                </div>
                <div>
                  <p className="font-medium text-white">{symbol.replace('USDT', '')}</p>
                  <p className="text-xs text-slate-500">USDT</p>
                </div>
              </div>
              
              <div className="text-right">
                <p className="font-medium text-white">${formatPrice(data.price)}</p>
                <Badge 
                  variant="outline" 
                  className={`text-xs ${
                    data.changePercent24h >= 0 
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' 
                      : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                  }`}
                >
                  {formatChange(data.changePercent24h)}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
