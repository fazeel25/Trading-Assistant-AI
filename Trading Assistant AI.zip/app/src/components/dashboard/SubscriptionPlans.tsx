import React, { useState } from 'react';
import { subscriptionPlans } from '@/lib/stripe';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check, Loader2, Sparkles, Zap, Crown } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

interface SubscriptionPlansProps {
  currentPlan?: string;
}

export const SubscriptionPlans: React.FC<SubscriptionPlansProps> = ({ currentPlan = 'free' }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [showDialog, setShowDialog] = useState(false);

  const handleSubscribe = async (planId: string) => {
    if (planId === 'free') return;
    
    setIsLoading(true);
    try {
      // In a real implementation, this would create a Stripe checkout session
      // For demo purposes, we'll show a dialog
      setShowDialog(true);
    } finally {
      setIsLoading(false);
    }
  };

  const getPlanIcon = (planId: string) => {
    switch (planId) {
      case 'free':
        return <Zap className="h-6 w-6 text-slate-400" />;
      case 'premium':
        return <Crown className="h-6 w-6 text-amber-400" />;
      default:
        return <Sparkles className="h-6 w-6 text-indigo-400" />;
    }
  };

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {subscriptionPlans.map((plan) => {
          const isCurrentPlan = currentPlan === plan.id;
          const isPremium = plan.id === 'premium';

          return (
            <Card 
              key={plan.id}
              className={`relative border-slate-800 bg-slate-950/50 ${
                isPremium ? 'ring-2 ring-indigo-500/50' : ''
              }`}
            >
              {isPremium && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <Badge className="bg-indigo-600 text-white">
                    <Sparkles className="h-3 w-3 mr-1" />
                    Recommended
                  </Badge>
                </div>
              )}
              
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getPlanIcon(plan.id)}
                    <div>
                      <CardTitle className="text-white">{plan.name}</CardTitle>
                      <CardDescription className="text-slate-400">
                        {plan.price === 0 ? 'Free forever' : `$${plan.price}/${plan.interval}`}
                      </CardDescription>
                    </div>
                  </div>
                  {isCurrentPlan && (
                    <Badge variant="outline" className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30">
                      Current Plan
                    </Badge>
                  )}
                </div>
              </CardHeader>
              
              <CardContent>
                <ul className="space-y-3">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <Check className="h-4 w-4 text-emerald-500 flex-shrink-0 mt-0.5" />
                      <span className="text-sm text-slate-300">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              
              <CardFooter>
                <Button
                  className={`w-full ${
                    isPremium 
                      ? 'bg-indigo-600 hover:bg-indigo-700 text-white' 
                      : 'bg-slate-800 hover:bg-slate-700 text-white'
                  }`}
                  disabled={isCurrentPlan || isLoading}
                  onClick={() => handleSubscribe(plan.id)}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : isCurrentPlan ? (
                    'Current Plan'
                  ) : plan.price === 0 ? (
                    'Get Started'
                  ) : (
                    'Upgrade Now'
                  )}
                </Button>
              </CardFooter>
            </Card>
          );
        })}
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="bg-slate-950 border-slate-800">
          <DialogHeader>
            <DialogTitle className="text-white">Coming Soon</DialogTitle>
            <DialogDescription className="text-slate-400">
              Stripe integration is being set up. Please check back later to upgrade your plan.
            </DialogDescription>
          </DialogHeader>
          <div className="p-4">
            <p className="text-sm text-slate-300">
              To complete the Stripe integration, you need to:
            </p>
            <ol className="list-decimal list-inside mt-2 space-y-1 text-sm text-slate-400">
              <li>Create a Stripe account at stripe.com</li>
              <li>Set up your products and prices in the Stripe Dashboard</li>
              <li>Add your Stripe API keys to the environment variables</li>
              <li>Create API endpoints for checkout and webhooks</li>
            </ol>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};
