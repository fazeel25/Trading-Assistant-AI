import React from 'react';
import type { TechnicalIndicators } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Activity, Gauge, TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface IndicatorPanelProps {
  indicators: TechnicalIndicators;
}

export const IndicatorPanel: React.FC<IndicatorPanelProps> = ({ indicators }) => {
  const { rsi, ma50, ma200, currentPrice } = indicators;

  // RSI interpretation
  const getRsiInterpretation = (value: number) => {
    if (value < 30) return { label: 'Oversold', color: 'text-emerald-500', icon: TrendingUp };
    if (value > 70) return { label: 'Overbought', color: 'text-rose-500', icon: TrendingDown };
    return { label: 'Neutral', color: 'text-amber-500', icon: Minus };
  };

  // MA Trend interpretation
  const getMaTrend = () => {
    if (currentPrice > ma50 && ma50 > ma200) {
      return { label: 'Strong Uptrend', color: 'text-emerald-500' };
    }
    if (currentPrice < ma50 && ma50 < ma200) {
      return { label: 'Strong Downtrend', color: 'text-rose-500' };
    }
    if (currentPrice > ma50) {
      return { label: 'Weak Uptrend', color: 'text-amber-500' };
    }
    return { label: 'Weak Downtrend', color: 'text-amber-500' };
  };

  const rsiInfo = getRsiInterpretation(rsi);
  const maTrend = getMaTrend();
  const RsiIcon = rsiInfo.icon;

  // Calculate RSI progress (0-100)
  const rsiProgress = Math.min(Math.max(rsi, 0), 100);

  return (
    <Card className="border-slate-800 bg-slate-950/50">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Gauge className="h-5 w-5 text-indigo-500" />
          Technical Indicators
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* RSI Section */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="h-4 w-4 text-slate-400" />
              <span className="text-sm font-medium text-slate-300">RSI (14)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className={`text-lg font-bold ${rsiInfo.color}`}>{rsi}</span>
              <span className={`text-xs px-2 py-1 rounded-full bg-slate-800 ${rsiInfo.color}`}>
                {rsiInfo.label}
              </span>
            </div>
          </div>
          
          <div className="relative">
            <Progress 
              value={rsiProgress} 
              className="h-2 bg-slate-800"
            />
            <div className="flex justify-between mt-1 text-xs text-slate-500">
              <span>Oversold (0)</span>
              <span>Neutral (50)</span>
              <span>Overbought (100)</span>
            </div>
          </div>

          <div className="flex items-center gap-2 p-3 rounded-lg bg-slate-900/50">
            <RsiIcon className={`h-5 w-5 ${rsiInfo.color}`} />
            <p className={`text-sm ${rsiInfo.color}`}>
              {rsi < 30 
                ? 'RSI indicates oversold conditions - potential buying opportunity' 
                : rsi > 70 
                ? 'RSI indicates overbought conditions - potential selling opportunity'
                : 'RSI shows neutral momentum - no clear directional bias'}
            </p>
          </div>
        </div>

        {/* Moving Averages Section */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-slate-400" />
            <span className="text-sm font-medium text-slate-300">Moving Averages</span>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-lg bg-slate-900/50 border border-slate-800">
              <p className="text-xs text-slate-500 mb-1">MA50</p>
              <p className="text-xl font-semibold text-white">${ma50.toLocaleString()}</p>
              <p className={`text-xs mt-1 ${currentPrice > ma50 ? 'text-emerald-500' : 'text-rose-500'}`}>
                Price is {currentPrice > ma50 ? 'above' : 'below'} MA50
              </p>
            </div>
            <div className="p-4 rounded-lg bg-slate-900/50 border border-slate-800">
              <p className="text-xs text-slate-500 mb-1">MA200</p>
              <p className="text-xl font-semibold text-white">${ma200.toLocaleString()}</p>
              <p className={`text-xs mt-1 ${currentPrice > ma200 ? 'text-emerald-500' : 'text-rose-500'}`}>
                Price is {currentPrice > ma200 ? 'above' : 'below'} MA200
              </p>
            </div>
          </div>

          <div className="p-4 rounded-lg bg-slate-900/50 border border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Trend Analysis</span>
              <span className={`text-sm font-medium ${maTrend.color}`}>{maTrend.label}</span>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500">Price vs MA50</span>
                <span className={currentPrice > ma50 ? 'text-emerald-500' : 'text-rose-500'}>
                  {currentPrice > ma50 ? 'Bullish' : 'Bearish'}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500">MA50 vs MA200</span>
                <span className={ma50 > ma200 ? 'text-emerald-500' : 'text-rose-500'}>
                  {ma50 > ma200 ? 'Golden Cross' : 'Death Cross'}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500">Price vs MA200</span>
                <span className={currentPrice > ma200 ? 'text-emerald-500' : 'text-rose-500'}>
                  {currentPrice > ma200 ? 'Long-term Bullish' : 'Long-term Bearish'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Summary */}
        <div className="p-4 rounded-lg bg-indigo-950/30 border border-indigo-800/50">
          <p className="text-sm font-medium text-indigo-300 mb-1">Indicator Summary</p>
          <p className="text-sm text-indigo-200/70">
            Based on RSI and Moving Average analysis, the current market shows{' '}
            <span className={maTrend.color}>{maTrend.label.toLowerCase()}</span>{' '}
            with RSI indicating{' '}
            <span className={rsiInfo.color}>{rsiInfo.label.toLowerCase()}</span>{' '}
            conditions.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};
