import type { CandlestickData, TechnicalIndicators } from '@/types';

/**
 * Calculate Relative Strength Index (RSI)
 * @param data - Array of closing prices
 * @param period - RSI period (default: 14)
 * @returns RSI value (0-100)
 */
export const calculateRSI = (data: number[], period: number = 14): number => {
  if (data.length < period + 1) {
    throw new Error(`Insufficient data for RSI calculation. Need at least ${period + 1} data points.`);
  }

  const closes = data.slice(-period - 1);
  let gains = 0;
  let losses = 0;

  // Calculate initial average gain and loss
  for (let i = 1; i <= period; i++) {
    const change = closes[i] - closes[i - 1];
    if (change > 0) {
      gains += change;
    } else {
      losses += Math.abs(change);
    }
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;

  // Calculate RSI using smoothed averages
  for (let i = period + 1; i < closes.length; i++) {
    const change = closes[i] - closes[i - 1];
    if (change > 0) {
      avgGain = (avgGain * (period - 1) + change) / period;
      avgLoss = (avgLoss * (period - 1)) / period;
    } else {
      avgGain = (avgGain * (period - 1)) / period;
      avgLoss = (avgLoss * (period - 1) + Math.abs(change)) / period;
    }
  }

  if (avgLoss === 0) {
    return 100;
  }

  const rs = avgGain / avgLoss;
  const rsi = 100 - (100 / (1 + rs));

  return Math.round(rsi * 100) / 100;
};

/**
 * Calculate Simple Moving Average (SMA)
 * @param data - Array of closing prices
 * @param period - MA period
 * @returns SMA value
 */
export const calculateSMA = (data: number[], period: number): number => {
  if (data.length < period) {
    throw new Error(`Insufficient data for SMA calculation. Need at least ${period} data points.`);
  }

  const sum = data.slice(-period).reduce((acc, price) => acc + price, 0);
  return Math.round((sum / period) * 100) / 100;
};

/**
 * Calculate Exponential Moving Average (EMA)
 * @param data - Array of closing prices
 * @param period - EMA period
 * @returns EMA value
 */
export const calculateEMA = (data: number[], period: number): number => {
  if (data.length < period) {
    throw new Error(`Insufficient data for EMA calculation. Need at least ${period} data points.`);
  }

  const multiplier = 2 / (period + 1);
  const sma = calculateSMA(data.slice(0, period), period);
  
  let ema = sma;
  for (let i = period; i < data.length; i++) {
    ema = (data[i] - ema) * multiplier + ema;
  }

  return Math.round(ema * 100) / 100;
};

/**
 * Calculate all technical indicators
 * @param candlesticks - Array of candlestick data
 * @returns TechnicalIndicators object
 */
export const calculateIndicators = (candlesticks: CandlestickData[]): TechnicalIndicators => {
  if (candlesticks.length < 200) {
    throw new Error('Insufficient candlestick data. Need at least 200 candles.');
  }

  const closes = candlesticks.map(c => c.close);
  const currentPrice = closes[closes.length - 1];

  return {
    rsi: calculateRSI(closes, 14),
    ma50: calculateSMA(closes, 50),
    ma200: calculateSMA(closes, 200),
    currentPrice: Math.round(currentPrice * 100) / 100,
    timestamp: new Date()
  };
};

/**
 * Determine market condition based on price and moving averages
 * @param price - Current price
 * @param ma50 - 50-period moving average
 * @param ma200 - 200-period moving average
 * @returns Market condition
 */
export const determineMarketCondition = (
  price: number,
  ma50: number,
  ma200: number
): 'bullish' | 'bearish' | 'neutral' => {
  // Golden Cross: Price > MA50 > MA200 (Bullish)
  if (price > ma50 && ma50 > ma200) {
    return 'bullish';
  }
  
  // Death Cross: Price < MA50 < MA200 (Bearish)
  if (price < ma50 && ma50 < ma200) {
    return 'bearish';
  }
  
  // Conflicting signals
  return 'neutral';
};

/**
 * Generate trading signal based on RSI and moving averages
 * @param rsi - RSI value
 * @param price - Current price
 * @param ma50 - 50-period moving average
 * @param ma200 - 200-period moving average
 * @returns Trading signal
 */
export const generateTradingSignal = (
  rsi: number,
  price: number,
  ma50: number,
  ma200: number
): { signal: 'possible_buy' | 'possible_sell' | 'wait'; confidence: 'high' | 'medium' | 'low' } => {
  const marketCondition = determineMarketCondition(price, ma50, ma200);
  
  // RSI signals
  const isOversold = rsi < 30;
  const isOverbought = rsi > 70;
  
  // Moving average signals
  const isBullishMA = price > ma50 && ma50 > ma200;
  const isBearishMA = price < ma50 && ma50 < ma200;
  
  // Combined analysis
  if (isOversold && (isBullishMA || marketCondition === 'neutral')) {
    return { signal: 'possible_buy', confidence: isBullishMA ? 'high' : 'medium' };
  }
  
  if (isOverbought && (isBearishMA || marketCondition === 'neutral')) {
    return { signal: 'possible_sell', confidence: isBearishMA ? 'high' : 'medium' };
  }
  
  // Trend following signals
  if (isBullishMA && rsi > 50 && rsi < 70) {
    return { signal: 'possible_buy', confidence: 'medium' };
  }
  
  if (isBearishMA && rsi < 50 && rsi > 30) {
    return { signal: 'possible_sell', confidence: 'medium' };
  }
  
  return { signal: 'wait', confidence: 'low' };
};

/**
 * Generate AI reasoning text based on indicators
 * @param indicators - Technical indicators
 * @param signal - Trading signal
 * @returns Reasoning text
 */
export const generateReasoning = (
  indicators: TechnicalIndicators,
  signal: 'possible_buy' | 'possible_sell' | 'wait'
): string => {
  const { rsi, ma50, ma200, currentPrice } = indicators;
  const reasons: string[] = [];
  
  // RSI analysis
  if (rsi < 30) {
    reasons.push(`RSI is at ${rsi}, indicating oversold conditions`);
  } else if (rsi > 70) {
    reasons.push(`RSI is at ${rsi}, indicating overbought conditions`);
  } else {
    reasons.push(`RSI is at ${rsi}, indicating neutral momentum`);
  }
  
  // Moving average analysis
  if (currentPrice > ma50 && ma50 > ma200) {
    reasons.push(`Price ($${currentPrice}) is above MA50 ($${ma50}) and MA200 ($${ma200}), showing strong bullish trend`);
  } else if (currentPrice < ma50 && ma50 < ma200) {
    reasons.push(`Price ($${currentPrice}) is below MA50 ($${ma50}) and MA200 ($${ma200}), showing strong bearish trend`);
  } else if (currentPrice > ma50) {
    reasons.push(`Price is above MA50 but relationship with MA200 is mixed`);
  } else {
    reasons.push(`Price is below MA50 but relationship with MA200 is mixed`);
  }
  
  // Signal summary
  if (signal === 'possible_buy') {
    reasons.push('Combined indicators suggest potential buying opportunity');
  } else if (signal === 'possible_sell') {
    reasons.push('Combined indicators suggest potential selling opportunity');
  } else {
    reasons.push('Mixed signals suggest waiting for clearer direction');
  }
  
  return reasons.join('. ') + '.';
};
