import type { 
  TradingInsight, 
  TechnicalIndicators, 
  MarketCondition,
  TradingSignal,
  ConfidenceLevel 
} from '@/types';
import { 
  calculateIndicators, 
  determineMarketCondition, 
  generateTradingSignal,
  generateReasoning 
} from '@/utils/indicators';
import { getKlines } from './binanceApi';

// AI Analysis Configuration
const AI_CONFIG = {
  rsiOversold: 30,
  rsiOverbought: 70,
  rsiNeutralLow: 40,
  rsiNeutralHigh: 60,
  confidenceThresholds: {
    high: 0.75,
    medium: 0.5
  }
};

/**
 * Calculate confidence score based on indicator alignment
 * @param indicators - Technical indicators
 * @param signal - Generated signal
 * @returns Confidence score (0-1)
 */
const calculateConfidenceScore = (
  indicators: TechnicalIndicators,
  signal: TradingSignal
): number => {
  const { rsi, ma50, ma200, currentPrice } = indicators;
  let score = 0;
  let factors = 0;
  
  // RSI factor
  if (signal === 'possible_buy') {
    if (rsi < 30) score += 1;
    else if (rsi < 40) score += 0.7;
    else if (rsi < 50) score += 0.4;
  } else if (signal === 'possible_sell') {
    if (rsi > 70) score += 1;
    else if (rsi > 60) score += 0.7;
    else if (rsi > 50) score += 0.4;
  }
  factors++;
  
  // Moving average alignment
  const priceAboveMA50 = currentPrice > ma50;
  const ma50AboveMA200 = ma50 > ma200;
  
  if (signal === 'possible_buy') {
    if (priceAboveMA50 && ma50AboveMA200) score += 1;
    else if (priceAboveMA50) score += 0.6;
    else if (ma50AboveMA200) score += 0.4;
  } else if (signal === 'possible_sell') {
    if (!priceAboveMA50 && !ma50AboveMA200) score += 1;
    else if (!priceAboveMA50) score += 0.6;
    else if (!ma50AboveMA200) score += 0.4;
  }
  factors++;
  
  // Trend strength (distance between MAs)
  const maSpread = Math.abs(ma50 - ma200) / ma200;
  if (maSpread > 0.1) score += 1;
  else if (maSpread > 0.05) score += 0.7;
  else score += 0.4;
  factors++;
  
  return score / factors;
};

/**
 * Determine confidence level from score
 * @param score - Confidence score (0-1)
 * @returns Confidence level
 */
const determineConfidenceLevel = (score: number): ConfidenceLevel => {
  if (score >= AI_CONFIG.confidenceThresholds.high) return 'high';
  if (score >= AI_CONFIG.confidenceThresholds.medium) return 'medium';
  return 'low';
};

/**
 * Generate comprehensive trading insight
 * @param symbol - Trading pair symbol
 * @param interval - Time interval
 * @returns Trading insight with analysis
 */
export const generateTradingInsight = async (
  symbol: string,
  interval: string = '1h'
): Promise<TradingInsight> => {
  try {
    // Fetch candlestick data
    const candlesticks = await getKlines(symbol, interval, 250);
    
    // Calculate technical indicators
    const indicators = calculateIndicators(candlesticks);
    
    // Determine market condition
    const marketCondition = determineMarketCondition(
      indicators.currentPrice,
      indicators.ma50,
      indicators.ma200
    );
    
    // Generate trading signal
    const { signal } = generateTradingSignal(
      indicators.rsi,
      indicators.currentPrice,
      indicators.ma50,
      indicators.ma200
    );
    
    // Calculate detailed confidence score
    const confidenceScore = calculateConfidenceScore(indicators, signal);
    const confidence = determineConfidenceLevel(confidenceScore);
    
    // Generate reasoning
    const reasoning = generateReasoning(indicators, signal);
    
    return {
      id: `${symbol}-${Date.now()}`,
      symbol,
      marketCondition,
      signal,
      confidence,
      reasoning,
      indicators,
      timestamp: new Date(),
      disclaimer: 'This is not financial advice. Trading involves significant risk. Always do your own research and consider consulting with a financial advisor before making investment decisions.'
    };
  } catch (error) {
    console.error('Error generating trading insight:', error);
    throw new Error(`Failed to generate trading insight for ${symbol}: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
};

/**
 * Batch generate insights for multiple symbols
 * @param symbols - Array of trading pairs
 * @param interval - Time interval
 * @returns Array of trading insights
 */
export const generateBatchInsights = async (
  symbols: string[],
  interval: string = '1h'
): Promise<TradingInsight[]> => {
  const insights: TradingInsight[] = [];
  
  for (const symbol of symbols) {
    try {
      const insight = await generateTradingInsight(symbol, interval);
      insights.push(insight);
      
      // Add delay to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 200));
    } catch (error) {
      console.error(`Failed to generate insight for ${symbol}:`, error);
    }
  }
  
  return insights;
};

/**
 * Get signal color for UI
 * @param signal - Trading signal
 * @returns Tailwind color class
 */
export const getSignalColor = (signal: TradingSignal): string => {
  switch (signal) {
    case 'possible_buy':
      return 'text-emerald-500';
    case 'possible_sell':
      return 'text-rose-500';
    case 'wait':
      return 'text-amber-500';
    default:
      return 'text-slate-500';
  }
};

/**
 * Get signal background color for UI
 * @param signal - Trading signal
 * @returns Tailwind background color class
 */
export const getSignalBgColor = (signal: TradingSignal): string => {
  switch (signal) {
    case 'possible_buy':
      return 'bg-emerald-500/10 border-emerald-500/30';
    case 'possible_sell':
      return 'bg-rose-500/10 border-rose-500/30';
    case 'wait':
      return 'bg-amber-500/10 border-amber-500/30';
    default:
      return 'bg-slate-500/10 border-slate-500/30';
  }
};

/**
 * Get market condition color for UI
 * @param condition - Market condition
 * @returns Tailwind color class
 */
export const getMarketConditionColor = (condition: MarketCondition): string => {
  switch (condition) {
    case 'bullish':
      return 'text-emerald-500';
    case 'bearish':
      return 'text-rose-500';
    case 'neutral':
      return 'text-amber-500';
    default:
      return 'text-slate-500';
  }
};

/**
 * Get confidence badge color for UI
 * @param confidence - Confidence level
 * @returns Tailwind color class
 */
export const getConfidenceColor = (confidence: ConfidenceLevel): string => {
  switch (confidence) {
    case 'high':
      return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
    case 'medium':
      return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
    case 'low':
      return 'bg-rose-500/20 text-rose-400 border-rose-500/30';
    default:
      return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
  }
};

/**
 * Format signal for display
 * @param signal - Trading signal
 * @returns Formatted string
 */
export const formatSignal = (signal: TradingSignal): string => {
  switch (signal) {
    case 'possible_buy':
      return 'Possible Buy';
    case 'possible_sell':
      return 'Possible Sell';
    case 'wait':
      return 'Wait';
    default:
      return signal;
  }
};

/**
 * Format market condition for display
 * @param condition - Market condition
 * @returns Formatted string
 */
export const formatMarketCondition = (condition: MarketCondition): string => {
  return condition.charAt(0).toUpperCase() + condition.slice(1);
};
