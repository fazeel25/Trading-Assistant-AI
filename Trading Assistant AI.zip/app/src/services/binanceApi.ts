import axios from 'axios';
import type { CandlestickData, MarketData } from '@/types';

const BINANCE_API_BASE = 'https://api.binance.com';

// Rate limiting configuration
const REQUEST_DELAY = 100; // ms between requests
let lastRequestTime = 0;

const delay = (ms: number): Promise<void> => new Promise(resolve => setTimeout(resolve, ms));

const rateLimitedRequest = async <T>(requestFn: () => Promise<T>): Promise<T> => {
  const now = Date.now();
  const timeSinceLastRequest = now - lastRequestTime;
  
  if (timeSinceLastRequest < REQUEST_DELAY) {
    await delay(REQUEST_DELAY - timeSinceLastRequest);
  }
  
  lastRequestTime = Date.now();
  return requestFn();
};

// Axios instance with default config
const binanceClient = axios.create({
  baseURL: BINANCE_API_BASE,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Error handler
const handleApiError = (error: any): never => {
  if (axios.isAxiosError(error)) {
    if (error.response) {
      const message = error.response.data?.msg || error.response.statusText;
      throw new Error(`Binance API Error: ${message}`);
    } else if (error.request) {
      throw new Error('Network error: Unable to reach Binance API');
    }
  }
  throw new Error('Unexpected error occurred');
};

/**
 * Get current price for a symbol
 * @param symbol - Trading pair (e.g., 'BTCUSDT')
 * @returns Current price
 */
export const getCurrentPrice = async (symbol: string): Promise<number> => {
  try {
    const response = await rateLimitedRequest(() =>
      binanceClient.get('/api/v3/ticker/price', { params: { symbol: symbol.toUpperCase() } })
    );
    return parseFloat(response.data.price);
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * Get 24hr ticker statistics
 * @param symbol - Trading pair
 * @returns Market data
 */
export const get24hrStats = async (symbol: string): Promise<MarketData> => {
  try {
    const response = await rateLimitedRequest(() =>
      binanceClient.get('/api/v3/ticker/24hr', { params: { symbol: symbol.toUpperCase() } })
    );
    
    const data = response.data;
    return {
      symbol: data.symbol,
      price: parseFloat(data.lastPrice),
      change24h: parseFloat(data.priceChange),
      changePercent24h: parseFloat(data.priceChangePercent),
      high24h: parseFloat(data.highPrice),
      low24h: parseFloat(data.lowPrice),
      volume24h: parseFloat(data.volume),
      lastUpdated: new Date(data.closeTime)
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * Get kline/candlestick data
 * @param symbol - Trading pair
 * @param interval - Kline interval (e.g., '1h', '4h', '1d')
 * @param limit - Number of candles to fetch (max 1000)
 * @returns Array of candlestick data
 */
export const getKlines = async (
  symbol: string,
  interval: string = '1h',
  limit: number = 200
): Promise<CandlestickData[]> => {
  try {
    const response = await rateLimitedRequest(() =>
      binanceClient.get('/api/v3/klines', {
        params: {
          symbol: symbol.toUpperCase(),
          interval,
          limit: Math.min(limit, 1000)
        }
      })
    );
    
    return response.data.map((kline: any[]) => ({
      time: kline[0],
      open: parseFloat(kline[1]),
      high: parseFloat(kline[2]),
      low: parseFloat(kline[3]),
      close: parseFloat(kline[4]),
      volume: parseFloat(kline[5])
    }));
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * Get multiple symbols' prices
 * @param symbols - Array of trading pairs
 * @returns Object with symbol-price mappings
 */
export const getMultiplePrices = async (symbols: string[]): Promise<Record<string, number>> => {
  try {
    const response = await rateLimitedRequest(() =>
      binanceClient.get('/api/v3/ticker/price')
    );
    
    const prices: Record<string, number> = {};
    const upperSymbols = symbols.map(s => s.toUpperCase());
    
    response.data.forEach((item: any) => {
      if (upperSymbols.includes(item.symbol)) {
        prices[item.symbol] = parseFloat(item.price);
      }
    });
    
    return prices;
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * Get available trading pairs
 * @returns Array of symbol information
 */
export const getExchangeInfo = async (): Promise<string[]> => {
  try {
    const response = await rateLimitedRequest(() =>
      binanceClient.get('/api/v3/exchangeInfo')
    );
    
    return response.data.symbols
      .filter((s: any) => s.status === 'TRADING' && s.quoteAsset === 'USDT')
      .map((s: any) => s.symbol);
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * Get order book for a symbol
 * @param symbol - Trading pair
 * @param limit - Depth limit
 * @returns Order book data
 */
export const getOrderBook = async (
  symbol: string,
  limit: number = 100
): Promise<{ bids: [number, number][]; asks: [number, number][] }> => {
  try {
    const response = await rateLimitedRequest(() =>
      binanceClient.get('/api/v3/depth', {
        params: {
          symbol: symbol.toUpperCase(),
          limit: Math.min(limit, 1000)
        }
      })
    );
    
    return {
      bids: response.data.bids.map((b: string[]) => [parseFloat(b[0]), parseFloat(b[1])]),
      asks: response.data.asks.map((a: string[]) => [parseFloat(a[0]), parseFloat(a[1])])
    };
  } catch (error) {
    return handleApiError(error);
  }
};

// WebSocket for real-time data (for future implementation)
export const createWebSocketConnection = (
  symbol: string,
  onMessage: (data: any) => void
): WebSocket => {
  const wsUrl = `wss://stream.binance.com:9443/ws/${symbol.toLowerCase()}@ticker`;
  const ws = new WebSocket(wsUrl);
  
  ws.onopen = () => {
    console.log(`WebSocket connected for ${symbol}`);
  };
  
  ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    onMessage(data);
  };
  
  ws.onerror = (error) => {
    console.error('WebSocket error:', error);
  };
  
  ws.onclose = () => {
    console.log(`WebSocket disconnected for ${symbol}`);
  };
  
  return ws;
};

// Popular trading pairs
export const POPULAR_PAIRS = [
  'BTCUSDT',
  'ETHUSDT',
  'BNBUSDT',
  'SOLUSDT',
  'ADAUSDT',
  'DOTUSDT',
  'AVAXUSDT',
  'MATICUSDT',
  'LINKUSDT',
  'UNIUSDT'
];

// Interval options
export const INTERVAL_OPTIONS = [
  { value: '1m', label: '1 Minute' },
  { value: '5m', label: '5 Minutes' },
  { value: '15m', label: '15 Minutes' },
  { value: '1h', label: '1 Hour' },
  { value: '4h', label: '4 Hours' },
  { value: '1d', label: '1 Day' },
  { value: '1w', label: '1 Week' }
];
