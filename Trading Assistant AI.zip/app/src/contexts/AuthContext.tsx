import React, { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { 
  auth,
  onAuthStateChanged, 
  signUpWithEmail, 
  signInWithEmail, 
  signInWithGoogle, 
  logOut,
  getUserDocument,
  updateUserSubscription,
  type FirebaseUser
} from '@/lib/mockAuth';
import type { User, SubscriptionType } from '@/types';

interface AuthContextType {
  user: User | null;
  firebaseUser: FirebaseUser | null;
  loading: boolean;
  error: string | null;
  signUp: (email: string, password: string, displayName: string) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signInWithGoogleAuth: () => Promise<void>;
  logout: () => Promise<void>;
  updateSubscription: (subscription: SubscriptionType) => Promise<void>;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(
      auth,
      async (fbUser: FirebaseUser | null) => {
        setLoading(true);
        if (fbUser) {
          setFirebaseUser(fbUser);
          try {
            const userData = await getUserDocument(fbUser.uid);
            setUser(userData);
          } catch (err) {
            console.error('Error fetching user data:', err);
            setError('Failed to load user data');
          }
        } else {
          setFirebaseUser(null);
          setUser(null);
        }
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, []);

  const signUp = async (email: string, password: string, displayName: string): Promise<void> => {
    try {
      setError(null);
      const newUser = await signUpWithEmail(email, password, displayName);
      setUser(newUser);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to sign up';
      setError(errorMessage);
      throw err;
    }
  };

  const signIn = async (email: string, password: string): Promise<void> => {
    try {
      setError(null);
      const loggedInUser = await signInWithEmail(email, password);
      setUser(loggedInUser);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to sign in';
      setError(errorMessage);
      throw err;
    }
  };

  const signInWithGoogleAuth = async (): Promise<void> => {
    try {
      setError(null);
      const loggedInUser = await signInWithGoogle();
      setUser(loggedInUser);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to sign in with Google';
      setError(errorMessage);
      throw err;
    }
  };

  const logout = async (): Promise<void> => {
    try {
      setError(null);
      await logOut();
      setUser(null);
      setFirebaseUser(null);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to log out';
      setError(errorMessage);
      throw err;
    }
  };

  const updateSubscription = async (subscription: SubscriptionType): Promise<void> => {
    try {
      if (!user) throw new Error('No user logged in');
      await updateUserSubscription(user.id, subscription);
      setUser({ ...user, subscription });
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to update subscription';
      setError(errorMessage);
      throw err;
    }
  };

  const clearError = (): void => {
    setError(null);
  };

  const value: AuthContextType = {
    user,
    firebaseUser,
    loading,
    error,
    signUp,
    signIn,
    signInWithGoogleAuth,
    logout,
    updateSubscription,
    clearError
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
