import { useState, useEffect, useCallback } from 'react';
import type { MarketData, CandlestickData, TradingInsight } from '@/types';
import { get24hrStats, getKlines, POPULAR_PAIRS } from '@/services/binanceApi';
import { generateTradingInsight } from '@/services/aiInsights';

interface UseTradingDataReturn {
  marketData: MarketData | null;
  candlesticks: CandlestickData[];
  insight: TradingInsight | null;
  loading: boolean;
  error: string | null;
  refreshData: () => Promise<void>;
}

export const useTradingData = (
  symbol: string,
  interval: string = '1h'
): UseTradingDataReturn => {
  const [marketData, setMarketData] = useState<MarketData | null>(null);
  const [candlesticks, setCandlesticks] = useState<CandlestickData[]>([]);
  const [insight, setInsight] = useState<TradingInsight | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      // Fetch market data and candlesticks in parallel
      const [stats, klines] = await Promise.all([
        get24hrStats(symbol),
        getKlines(symbol, interval, 250)
      ]);

      setMarketData(stats);
      setCandlesticks(klines);

      // Generate AI insight
      const tradingInsight = await generateTradingInsight(symbol, interval);
      setInsight(tradingInsight);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch trading data';
      setError(errorMessage);
      console.error('Error fetching trading data:', err);
    } finally {
      setLoading(false);
    }
  }, [symbol, interval]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return {
    marketData,
    candlesticks,
    insight,
    loading,
    error,
    refreshData: fetchData
  };
};

interface UseMultipleMarketDataReturn {
  marketData: Record<string, MarketData>;
  loading: boolean;
  error: string | null;
  refreshData: () => Promise<void>;
}

export const useMultipleMarketData = (
  symbols: string[] = POPULAR_PAIRS.slice(0, 5)
): UseMultipleMarketDataReturn => {
  const [marketData, setMarketData] = useState<Record<string, MarketData>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const data: Record<string, MarketData> = {};
      
      for (const symbol of symbols) {
        try {
          const stats = await get24hrStats(symbol);
          data[symbol] = stats;
          // Small delay to avoid rate limiting
          await new Promise(resolve => setTimeout(resolve, 100));
        } catch (err) {
          console.error(`Error fetching ${symbol}:`, err);
        }
      }

      setMarketData(data);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch market data';
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  }, [symbols]);

  useEffect(() => {
    fetchData();
    
    // Auto-refresh every 30 seconds
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, [fetchData]);

  return {
    marketData,
    loading,
    error,
    refreshData: fetchData
  };
};

interface UseInsightsReturn {
  insights: TradingInsight[];
  loading: boolean;
  error: string | null;
  refreshInsights: () => Promise<void>;
}

export const useInsights = (
  symbols: string[] = POPULAR_PAIRS.slice(0, 3),
  interval: string = '1h'
): UseInsightsReturn => {
  const [insights, setInsights] = useState<TradingInsight[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchInsights = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const newInsights: TradingInsight[] = [];
      
      for (const symbol of symbols) {
        try {
          const insight = await generateTradingInsight(symbol, interval);
          newInsights.push(insight);
          await new Promise(resolve => setTimeout(resolve, 200));
        } catch (err) {
          console.error(`Error generating insight for ${symbol}:`, err);
        }
      }

      setInsights(newInsights);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to generate insights';
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  }, [symbols, interval]);

  useEffect(() => {
    fetchInsights();
  }, [fetchInsights]);

  return {
    insights,
    loading,
    error,
    refreshInsights: fetchInsights
  };
};
