import React from 'react';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { AuthPage } from '@/components/pages/AuthPage';
import { DashboardPage } from '@/components/pages/DashboardPage';
import { Toaster } from '@/components/ui/sonner';
import { Loader2 } from 'lucide-react';
import './App.css';

// Loading Screen Component
const LoadingScreen: React.FC = () => (
  <div className="min-h-screen bg-slate-950 flex items-center justify-center">
    <div className="flex flex-col items-center gap-4">
      <div className="w-12 h-12 rounded-lg bg-indigo-600 flex items-center justify-center animate-pulse">
        <Loader2 className="h-6 w-6 text-white animate-spin" />
      </div>
      <p className="text-slate-400">Loading...</p>
    </div>
  </div>
);

// Main App Content
const AppContent: React.FC = () => {
  const { user, loading } = useAuth();

  if (loading) {
    return <LoadingScreen />;
  }

  return user ? <DashboardPage /> : <AuthPage />;
};

// Main App Component
function App() {
  return (
    <AuthProvider>
      <AppContent />
      <Toaster 
        position="top-right"
        toastOptions={{
          style: {
            background: '#0f172a',
            border: '1px solid #1e293b',
            color: '#f8fafc',
          },
        }}
      />
    </AuthProvider>
  );
}

export default App;
