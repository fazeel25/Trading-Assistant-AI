// User Types
export interface User {
  id: string;
  email: string;
  displayName: string | null;
  photoURL: string | null;
  subscription: SubscriptionType;
  createdAt: Date;
  lastLoginAt: Date;
}

export type SubscriptionType = 'free' | 'premium';

export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  interval: 'month' | 'year';
  features: string[];
  stripePriceId: string;
}

// Market Data Types
export interface MarketData {
  symbol: string;
  price: number;
  change24h: number;
  changePercent24h: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  lastUpdated: Date;
}

export interface CandlestickData {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

// Technical Indicator Types
export interface TechnicalIndicators {
  rsi: number;
  ma50: number;
  ma200: number;
  currentPrice: number;
  timestamp: Date;
}

export interface IndicatorConfig {
  rsiPeriod: number;
  maShortPeriod: number;
  maLongPeriod: number;
}

// AI Insight Types
export type MarketCondition = 'bullish' | 'bearish' | 'neutral';
export type TradingSignal = 'possible_buy' | 'possible_sell' | 'wait';
export type ConfidenceLevel = 'high' | 'medium' | 'low';

export interface TradingInsight {
  id: string;
  symbol: string;
  marketCondition: MarketCondition;
  signal: TradingSignal;
  confidence: ConfidenceLevel;
  reasoning: string;
  indicators: TechnicalIndicators;
  timestamp: Date;
  disclaimer: string;
}

// Alert Types
export interface PriceAlert {
  id: string;
  userId: string;
  symbol: string;
  targetPrice: number;
  condition: 'above' | 'below';
  isActive: boolean;
  createdAt: Date;
  triggeredAt?: Date;
}

// History Types
export interface AnalysisHistory {
  id: string;
  userId: string;
  symbol: string;
  insight: TradingInsight;
  createdAt: Date;
}

// API Response Types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

// Component Props Types
export interface ChartProps {
  symbol: string;
  interval?: string;
  height?: number;
}

export interface SignalCardProps {
  insight: TradingInsight;
}

export interface IndicatorDisplayProps {
  indicators: TechnicalIndicators;
}
